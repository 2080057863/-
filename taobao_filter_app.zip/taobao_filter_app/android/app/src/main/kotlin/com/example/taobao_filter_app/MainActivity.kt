package com.example.taobao_filter_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

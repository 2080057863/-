import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(TaobaoFilterApp());
}

class TaobaoFilterApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '淘宝商品筛选器',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: FilterPage(),
    );
  }
}

class FilterPage extends StatefulWidget {
  @override
  _FilterPageState createState() => _FilterPageState();
}

class _FilterPageState extends State<FilterPage> {
  final TextEditingController _keywordController = TextEditingController();
  final TextEditingController _minPriceController = TextEditingController();
  final TextEditingController _maxPriceController = TextEditingController();
  final TextEditingController _maxSalesController = TextEditingController();

  bool _showDeposit = false; // 保证金复选框状态

  List<String> _results = []; // 存储搜索结果
  late WebViewController _webViewController;

  void _startSearch() {
    // 这里是触发搜索逻辑的函数
    final keyword = _keywordController.text;
    final minPrice = _minPriceController.text;
    final maxPrice = _maxPriceController.text;
    final maxSales = _maxSalesController.text;

    // 简单校验输入
    if (keyword.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("请输入搜索关键词!")),
      );
      return;
    }

    setState(() {
      _results = ["正在搜索:$keyword,价格区间:$minPrice-$maxPrice,销量:$maxSales"];
    });

    // 调用淘宝网页搜索 (WebView 注入 JavaScript 的简化示例)
    _webViewController.loadUrl("https://www.taobao.com/");
  }

  Widget _buildCheckbox() {
    return Row(
      children: [
        Checkbox(
          value: _showDeposit,
          onChanged: (value) {
            setState(() {
              _showDeposit = value!;
            });
          },
        ),
        Text(_showDeposit ? "✅ 显示商家保证金" : "☑️ 显示商家保证金"),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('淘宝商品筛选器'),
      ),
      body: Column(
        children: [
          // 输入筛选条件区域
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                TextField(
                  controller: _keywordController,
                  decoration: InputDecoration(labelText: '关键词'),
                ),
                TextField(
                  controller: _minPriceController,
                  decoration: InputDecoration(labelText: '最低价格'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: _maxPriceController,
                  decoration: InputDecoration(labelText: '最高价格'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: _maxSalesController,
                  decoration: InputDecoration(labelText: '最大销量'),
                  keyboardType: TextInputType.number,
                ),
                _buildCheckbox(),
                ElevatedButton(
                  onPressed: _startSearch,
                  child: Text('开始搜索'),
                ),
              ],
            ),
          ),
          Divider(),
          // 展示搜索结果
          Expanded(
            child: _results.isEmpty
                ? Center(child: Text('暂无搜索结果'))
                : ListView.builder(
                    itemCount: _results.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(_results[index]),
                      );
                    },
                  ),
          ),
          // WebView 执行淘宝搜索
          Container(
            height: 1, // 隐藏 WebView
            child: WebView(
              initialUrl: 'about:blank',
              javascriptMode: JavascriptMode.unrestricted,
              onWebViewCreated: (controller) {
                _webViewController = controller;
              },
            ),
          ),
        ],
      ),
    );
  }
}
